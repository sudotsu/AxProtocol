"""
AxProtocol War Room — Hybrid Runner with FULL ENFORCEMENT v2.3
=================================================================
Changes from previous version:
- TAES evaluation after each role
- Score validation with threshold enforcement
- Ledger logging for all executions
- CAM lease tracking
- IRD-based Reality Reconciliation Pass (RRP)
"""

import os, sys, re, csv, json, uuid
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional
from dotenv import load_dotenv
from openai import OpenAI

# Import AxProtocol enforcement modules
from taes_evaluation import evaluate_taes, check_cognitive_disalignment
from score_validator import extract_scores, validate_scores, format_score_block
from auth import CAMLease, validate_op_token
from ledger import log_execution, get_last_n_entries, verify_hash_chain

# ────────────────────────────────────────────────────────────────────────────
# 0) Setup
# ────────────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parents[2]
load_dotenv(BASE_DIR / ".env")

try:
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
except Exception as e:
    raise SystemExit(f"[ERROR] OpenAI init failed: {e}")

# ────────────────────────────────────────────────────────────────────────────
# 1) Tiered model selection
# ────────────────────────────────────────────────────────────────────────────
TIER = os.getenv("TIER", "DEV").upper()
MODEL_MAP = {
    "DEV": os.getenv("MODEL_DEV", "gpt-4o-mini"),
    "PREP": os.getenv("MODEL_PREP", "gpt-4o-turbo"),
    "CLIENT": os.getenv("MODEL_CLIENT", "gpt-4o"),
}
MODEL = MODEL_MAP.get(TIER, "gpt-4o-mini")
print(f"[AxProtocol] Tier={TIER}  →  Model={MODEL}")

# Domain for TAES (can be set via env or CLI arg)
DOMAIN = os.getenv("DOMAIN", "marketing").lower()

# ────────────────────────────────────────────────────────────────────────────
# 2) Directive loading (same as before)
# ────────────────────────────────────────────────────────────────────────────
def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf8") if path.exists() else f"[Missing: {path.name}]"

def load_directives():
    files = {
        "D0":   BASE_DIR / "core" / "AxProtocol_v0_CORE-CHANGE-CONTROL.txt",
        "CORE": BASE_DIR / "AxProtocol_v2.1a_MASTER.txt",
        "ADD":  BASE_DIR / "AxProtocol_v2.1b_ADDENDUM-WarRoomIntegration.txt",
        "AAL":  BASE_DIR / "AxProtocol_v2.1c_LAYER-AAL.txt",
        "TAES": BASE_DIR / "AxProtocol_v2.2_LAYER-TAES.txt",
        "RDL":  BASE_DIR / "AxProtocol_v2.3_LAYER-RDL.txt",
    }
    return {k: _read_text(v) for k, v in files.items()}

DIRECTIVES = load_directives()

BRIEFINGS = {
    "core":  "Enforce AxProtocol Core (1–14): truth discipline, logic integrity, contradiction detection.",
    "add":   "Apply War-Room Addendum (15–19): objective grounding, scoring ≥85, handoff, efficiency, client-readiness.",
    "aal":   "Respect Authority Assertion (20–24): Operator supremacy, CAM lease, immutable ledger, killchain, drift monitor.",
    "taes":  "Use TAES (25–25c): weigh Logical/Practical/Probable, IRD>0.5 → RRP.",
    "rdl":   "Red-Team Layer (26–28): falsification MAS, CV detection, residual risk, structured dissent.",
}

def compose_system(role_prompt: str, include=("core","add","aal","taes","rdl"), ask_full=None) -> str:
    buf = [BRIEFINGS[k] for k in include if k in BRIEFINGS]
    if role_prompt:
        buf.insert(0, role_prompt.strip())
    return "\n\n".join(buf)

# ────────────────────────────────────────────────────────────────────────────
# 3) Role loading
# ────────────────────────────────────────────────────────────────────────────
STRATEGIST = ANALYST = PRODUCER = COURIER = CRITIC = None

try:
    from load_roles import load_roles_by_pattern
    BUILD_TYPE = os.getenv("BUILD_TYPE", "stable")
    _roles = load_roles_by_pattern(BUILD_TYPE)
    STRATEGIST = _roles["strategist"]["content"]
    ANALYST    = _roles["analyst"]["content"]
    PRODUCER   = _roles["producer"]["content"]
    COURIER    = _roles["courier"]["content"]
    CRITIC     = _roles["critic"]["content"]
    print(f"✅ Roles loaded via loader ({BUILD_TYPE}).")
except Exception as e:
    print(f"⚠️ Role loader not available — using inline defaults.\n{e}")
    STRATEGIST = (
        "Role: Strategist. Define positioning, 3 audiences, 3 hooks, 3-step plan. "
        "Be decisive; ground in objective. End with KPI or action (Directive 15)."
    )
    ANALYST = (
        "Role: Analyst. Pressure-test assumptions; risks→mitigations; 3 KPIs with numeric targets; "
        "A/B plan; short validation table. Prioritize 95% workable now. Score ≥85."
    )
    PRODUCER = (
        "Role: Producer. Create publishable assets for Nextdoor, Facebook, Craigslist (≤180 words each), "
        "3 alt headlines, 1 proof bullet. Clear CTA. Platform-specific. Score ≥85."
    )
    COURIER = (
        "Role: Courier. Build D1–D7 schedule (times + channels), DM plan, KPI tracker, "
        "3 fallback moves if leads < target by Day 3. Score ≥85."
    )
    CRITIC = (
        "Role: Critic. Audit for compliance, clarity, proof, CTA power, local tone. "
        "List 'Issue→Fix' pairs, give five 0–100 ratings + average. If <85, revise once, re-score."
    )

# ────────────────────────────────────────────────────────────────────────────
# 4) Core chat function
# ────────────────────────────────────────────────────────────────────────────
def llm(system_text: str, user_text: str, temperature=0.4, max_tokens=1600) -> str:
    r = client.chat.completions.create(
        model=MODEL,
        temperature=temperature,
        max_tokens=max_tokens,
        messages=[
            {"role": "system", "content": system_text},
            {"role": "user", "content": user_text},
        ],
    )
    return r.choices[0].message.content

# ────────────────────────────────────────────────────────────────────────────
# 5) War Room chain WITH ENFORCEMENT
# ────────────────────────────────────────────────────────────────────────────
def run_chain(objective: str, session_id: Optional[str] = None):
    """
    Execute 5-role chain with full AxProtocol enforcement:
    - TAES evaluation after each role
    - Score validation (≥85 threshold)
    - Ledger logging
    - CAM lease tracking
    - RRP trigger on high IRD
    """

    if not session_id:
        session_id = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

    print(f"\n[AxProtocol] Session: {session_id}")
    print(f"[AxProtocol] Domain: {DOMAIN}")

    # Initialize CAM lease (Directive 21)
    cam_lease = CAMLease(duration_seconds=180)

    results = {}

    # ────────────────────────────────────────────────────────────────────────
    # STRATEGIST
    # ────────────────────────────────────────────────────────────────────────
    print("\n[1/5] Strategist...")
    sys_s = compose_system(STRATEGIST, ask_full=objective)
    s = llm(sys_s, f"Objective:\n{objective}\nReturn positioning, audiences, hooks, 3-step plan.")

    # Log to ledger
    log_execution(
        session_id=session_id,
        agent_id=f"strategist-{uuid.uuid4().hex[:8]}",
        role_name="Strategist",
        action="generate_strategy",
        input_text=objective,
        output_text=s,
        directive=15
    )

    # TAES evaluation
    taes_s = evaluate_taes(s, domain=DOMAIN, session_id=session_id, role_name="Strategist")
    print(f"   TAES → IV: {taes_s['integrity_vector']}, IRD: {taes_s['ird']}")

    # Score validation
    scores_s = extract_scores(s)
    if scores_s:
        validation_s = validate_scores(scores_s, threshold=85)
        print(f"   Scores → {validation_s['reason']}")
        if not validation_s['valid']:
            print(f"   ⚠️ Below threshold: {validation_s['below_threshold']}")

    results['strategist'] = {
        'output': s,
        'taes': taes_s,
        'scores': scores_s,
        'validation': validation_s if scores_s else None
    }

    # Check CAM lease
    if cam_lease.is_expired():
        print("   ⚠️ CAM lease expired - requesting OP_AUTH extension")
        # In production, this would halt and wait for operator

    # ────────────────────────────────────────────────────────────────────────
    # ANALYST
    # ────────────────────────────────────────────────────────────────────────
    print("\n[2/5] Analyst...")
    sys_a = compose_system(ANALYST, ask_full=objective)
    a = llm(sys_a, f"Objective:\n{objective}\nStrategist:\n{s}\n"
                   "Return assumptions→risks→mitigations per hook; 3 KPIs; A/B plan; validation table.")

    log_execution(
        session_id=session_id,
        agent_id=f"analyst-{uuid.uuid4().hex[:8]}",
        role_name="Analyst",
        action="analyze_strategy",
        input_text=s,
        output_text=a,
        directive=16
    )

    taes_a = evaluate_taes(a, domain=DOMAIN, session_id=session_id, role_name="Analyst")
    print(f"   TAES → IV: {taes_a['integrity_vector']}, IRD: {taes_a['ird']}")

    scores_a = extract_scores(a)
    if scores_a:
        validation_a = validate_scores(scores_a, threshold=85)
        print(f"   Scores → {validation_a['reason']}")

    results['analyst'] = {
        'output': a,
        'taes': taes_a,
        'scores': scores_a,
        'validation': validation_a if scores_a else None
    }

    # ────────────────────────────────────────────────────────────────────────
    # PRODUCER (draft)
    # ────────────────────────────────────────────────────────────────────────
    print("\n[3/5] Producer (draft)...")
    sys_p = compose_system(PRODUCER, ask_full=objective)
    p_draft = llm(sys_p, f"Objective:\n{objective}\nStrategist:\n{s}\nAnalyst:\n{a}\n"
                         "Return 3 platform assets + 3 alt headlines each + 1 proof bullet per asset. Publishable tone.")

    log_execution(
        session_id=session_id,
        agent_id=f"producer-{uuid.uuid4().hex[:8]}",
        role_name="Producer",
        action="create_assets_draft",
        input_text=f"{s}\n\n{a}",
        output_text=p_draft,
        directive=19
    )

    taes_p_draft = evaluate_taes(p_draft, domain=DOMAIN, session_id=session_id, role_name="Producer-Draft")
    print(f"   TAES → IV: {taes_p_draft['integrity_vector']}, IRD: {taes_p_draft['ird']}")

    # ────────────────────────────────────────────────────────────────────────
    # COURIER (draft)
    # ────────────────────────────────────────────────────────────────────────
    print("\n[4/5] Courier (draft)...")
    sys_c = compose_system(COURIER, ask_full=objective)
    c_draft = llm(sys_c, f"Objective:\n{objective}\nStrategist:\n{s}\nAnalyst:\n{a}\nProducer [Draft]:\n{p_draft}\n"
                         "Return D1–D7 schedule, DM plan, KPI tracker, 3 fallback moves.")

    log_execution(
        session_id=session_id,
        agent_id=f"courier-{uuid.uuid4().hex[:8]}",
        role_name="Courier",
        action="build_schedule_draft",
        input_text=p_draft,
        output_text=c_draft,
        directive=17
    )

    taes_c_draft = evaluate_taes(c_draft, domain=DOMAIN, session_id=session_id, role_name="Courier-Draft")
    print(f"   TAES → IV: {taes_c_draft['integrity_vector']}, IRD: {taes_c_draft['ird']}")

    # ────────────────────────────────────────────────────────────────────────
    # CRITIC
    # ────────────────────────────────────────────────────────────────────────
    print("\n[5/5] Critic...")
    sys_crit = compose_system(CRITIC, ask_full=objective)
    crit = llm(sys_crit, f"Evaluate Producer [Draft] and Courier [Draft]. Return Issues→Fixes, rewrites, "
                         f"five 0–100 ratings + average, and readiness tag.\n"
                         f"Producer [Draft]:\n{p_draft}\n\nCourier [Draft]:\n{c_draft}")

    log_execution(
        session_id=session_id,
        agent_id=f"critic-{uuid.uuid4().hex[:8]}",
        role_name="Critic",
        action="audit_outputs",
        input_text=f"{p_draft}\n\n{c_draft}",
        output_text=crit,
        directive=15
    )

    taes_crit = evaluate_taes(crit, domain=DOMAIN, session_id=session_id, role_name="Critic")
    print(f"   TAES → IV: {taes_crit['integrity_vector']}, IRD: {taes_crit['ird']}")

    scores_crit = extract_scores(crit)
    if scores_crit:
        validation_crit = validate_scores(scores_crit, threshold=85)
        print(f"   Scores → {validation_crit['reason']}")

    # ────────────────────────────────────────────────────────────────────────
    # PRODUCER (revised)
    # ────────────────────────────────────────────────────────────────────────
    print("\n[Revision] Producer...")
    p_rev = llm(sys_p, f"Apply Critic fixes. Return [Revised] assets only.\n"
                       f"Critic:\n{crit}\nProducer [Draft]:\n{p_draft}")

    log_execution(
        session_id=session_id,
        agent_id=f"producer-rev-{uuid.uuid4().hex[:8]}",
        role_name="Producer-Revised",
        action="revise_assets",
        input_text=crit,
        output_text=p_rev,
        directive=15
    )

    taes_p_rev = evaluate_taes(p_rev, domain=DOMAIN, session_id=session_id, role_name="Producer-Revised")
    print(f"   TAES → IV: {taes_p_rev['integrity_vector']}, IRD: {taes_p_rev['ird']}")

    # RRP check (Directive 25)
    if taes_p_rev['requires_rrp']:
        print(f"   ⚠️ IRD > 0.5 detected - Reality Reconciliation Pass recommended")

    results['producer_revised'] = {
        'output': p_rev,
        'taes': taes_p_rev
    }

    # ────────────────────────────────────────────────────────────────────────
    # COURIER (revised)
    # ────────────────────────────────────────────────────────────────────────
    print("\n[Revision] Courier...")
    c_rev = llm(sys_c, f"Adjust per Critic. Return [Revised] calendar + KPI table.\n"
                       f"Critic:\n{crit}\nCourier [Draft]:\n{c_draft}")

    log_execution(
        session_id=session_id,
        agent_id=f"courier-rev-{uuid.uuid4().hex[:8]}",
        role_name="Courier-Revised",
        action="revise_schedule",
        input_text=crit,
        output_text=c_rev,
        directive=15
    )

    taes_c_rev = evaluate_taes(c_rev, domain=DOMAIN, session_id=session_id, role_name="Courier-Revised")
    print(f"   TAES → IV: {taes_c_rev['integrity_vector']}, IRD: {taes_c_rev['ird']}")

    if taes_c_rev['requires_rrp']:
        print(f"   ⚠️ IRD > 0.5 detected - Reality Reconciliation Pass recommended")

    results['courier_revised'] = {
        'output': c_rev,
        'taes': taes_c_rev
    }

    # ────────────────────────────────────────────────────────────────────────
    # Final checks
    # ────────────────────────────────────────────────────────────────────────
    print("\n[AxProtocol] Chain complete. Running final checks...")

    # Check for cognitive disalignment (Directive 25b)
    disalignment = check_cognitive_disalignment()
    if disalignment['alert']:
        print(f"   ⚠️ {disalignment['reason']}")

    # Verify ledger integrity (Directive 22)
    integrity = verify_hash_chain()
    if not integrity['valid']:
        print(f"   ❌ Ledger integrity compromised: {integrity['broken']}")
    else:
        print(f"   ✅ Ledger verified ({integrity['entries']} entries)")

    return s, a, p_rev, c_rev, crit, results

# ────────────────────────────────────────────────────────────────────────────
# 6) KPI extraction (unchanged)
# ────────────────────────────────────────────────────────────────────────────
def extract_kpi_rows(markdown_text: str):
    pattern = r"\| *([^\|]+)\| *([^\|]+)\| *([^\|]+)\|"
    rows = re.findall(pattern, markdown_text)
    out = []
    for r in rows:
        if "KPI" in r[0] or "---" in r[0]:
            continue
        out.append([x.strip() for x in r])
    return out

# ────────────────────────────────────────────────────────────────────────────
# 7) Logging + ROI JSON
# ────────────────────────────────────────────────────────────────────────────
LOG_DIR = BASE_DIR / "logs" / "sessions"
LOG_DIR.mkdir(parents=True, exist_ok=True)

def log_session(objective, s, a, p_rev, c_rev, crit, results):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")
    log_path = LOG_DIR / f"{ts}_{TIER.lower()}.log"

    with open(log_path, "w", encoding="utf8") as f:
        f.write(f"[Timestamp] {ts} UTC\n[Model] {MODEL}\n[Tier] {TIER}\n[Domain] {DOMAIN}\n\n")
        f.write("[Objective]\n" + objective + "\n\n")
        f.write("## STRATEGIST\n" + s + "\n\n")

        # Add TAES data
        if 'strategist' in results:
            taes = results['strategist']['taes']
            f.write(f"TAES → IV: {taes['integrity_vector']}, IRD: {taes['ird']}, RRP: {taes['requires_rrp']}\n\n")

        f.write("## ANALYST\n" + a + "\n\n")

        if 'analyst' in results:
            taes = results['analyst']['taes']
            f.write(f"TAES → IV: {taes['integrity_vector']}, IRD: {taes['ird']}, RRP: {taes['requires_rrp']}\n\n")

        f.write("## PRODUCER [Revised]\n" + p_rev + "\n\n")

        if 'producer_revised' in results:
            taes = results['producer_revised']['taes']
            f.write(f"TAES → IV: {taes['integrity_vector']}, IRD: {taes['ird']}, RRP: {taes['requires_rrp']}\n\n")

        f.write("## COURIER [Revised]\n" + c_rev + "\n\n")

        if 'courier_revised' in results:
            taes = results['courier_revised']['taes']
            f.write(f"TAES → IV: {taes['integrity_vector']}, IRD: {taes['ird']}, RRP: {taes['requires_rrp']}\n\n")

        f.write("## CRITIC\n" + crit + "\n")

    # ROI trigger detection
    if "[Tier: Immediate ROI]" in (s + a + p_rev + c_rev + crit):
        payload = {
            "trigger": "AxP_Curve_ImmediateROI",
            "timestamp": ts,
            "tier": TIER,
            "model": MODEL,
            "domain": DOMAIN,
            "objective": objective[:300],
            "summary": "Immediate ROI trigger detected in AxProtocol chain output.",
            "source": "AxProtocol War Room v2.3",
        }
        with open(LOG_DIR / f"{ts}_{TIER.lower()}_ROI.json", "w", encoding="utf8") as jf:
            json.dump(payload, jf, indent=2)

    # KPI CSV
    kpi_rows = extract_kpi_rows(c_rev)
    if kpi_rows:
        csv_path = BASE_DIR / "logs" / "kpi_log.csv"
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        header = ["timestamp", "objective", "kpi", "target", "status"]
        exists = csv_path.exists()
        with open(csv_path, "a", newline="", encoding="utf8") as csvf:
            w = csv.writer(csvf)
            if not exists:
                w.writerow(header)
            for kpi, target, status in kpi_rows:
                w.writerow([ts, objective, kpi, target, status])

    return str(log_path)

# ────────────────────────────────────────────────────────────────────────────
# 8) Entry point
# ────────────────────────────────────────────────────────────────────────────
def main():
    if len(sys.argv) > 1:
        objective = " ".join(sys.argv[1:])
    else:
        objective = (
            "Book 5 local jobs in 7 days for a tree service in Omaha. Create 3 assets "
            "(Nextdoor, Facebook, Craigslist; ≤180 words each; 3 alt headlines each); "
            "D1–D7 schedule with posting times, bumps, follow-ups, short DM scripts; "
            "KPI table (Day|Posts|Leads|Booked|Rev|Notes). Offer: 20% gap-fill. "
            "Cross-sell lawn/power wash/hauling. Contact: 402-306-4724."
        )

    print("\n[AxProtocol] Running governed five-role chain with FULL ENFORCEMENT...")
    print("[AxProtocol] TAES evaluation, score validation, and ledger logging active.")

    s, a, p_rev, c_rev, crit, results = run_chain(objective)
    log_file = log_session(objective, s, a, p_rev, c_rev, crit, results)

    print(f"\n✅ Complete. Session log: {log_file}")
    print(f"✅ Ledger: logs/ledger/audit_ledger.db")
    print(f"✅ IRD log: logs/ird_log.csv\n")

if __name__ == "__main__":
    main()